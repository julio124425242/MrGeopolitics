/* Comportamento das páginas de artigo:
   1. alternar entre versão rápida e análise completa
   2. desenhar gráficos de linha e de barras a partir de dados simples

   Para um artigo novo, basta copiar o modelo e chamar
   Heartland.linhas({...}) ou Heartland.barras({...}) com seus dados. */
(function () {
  var NS = 'http://www.w3.org/2000/svg';
  var DISPLAY = 'var(--display)';

  function el(tag, attrs, text) {
    var e = document.createElementNS(NS, tag);
    for (var k in attrs) e.setAttribute(k, attrs[k]);
    if (text != null) e.textContent = text;
    return e;
  }
  function num(n) { return n.toLocaleString('pt-BR'); }

  function titulos(svg, titulo, subtitulo) {
    if (titulo) svg.appendChild(el('text', { x: 24, y: 38, 'font-size': 20, 'font-weight': 600, fill: 'var(--ink)', 'font-family': DISPLAY }, titulo));
    if (subtitulo) svg.appendChild(el('text', { x: 24, y: 58, 'font-size': 15, fill: 'var(--muted)', 'font-family': DISPLAY }, subtitulo));
  }

  /* Gráfico de linhas.
     { alvo:'chart-pop', titulo, subtitulo, eixoX:[2025,2050], maxY:1500,
       marcasY:[0,500,1000,1500], unidade:'milhões',
       series:[{nome:'China', cor:'var(--cn)', valores:[1416,1260]}] } */
  function linhas(cfg) {
    var svg = document.getElementById(cfg.alvo);
    if (!svg || svg.childNodes.length) return;
    var left = 70, topo = 90, base = 320, w = 540;
    var xs = cfg.eixoX, n = xs.length;
    var x = function (i) { return left + (i / (n - 1)) * w; };
    var y = function (v) { return base - (v / cfg.maxY) * (base - topo); };

    titulos(svg, cfg.titulo, cfg.subtitulo);
    (cfg.marcasY || []).forEach(function (t) {
      svg.appendChild(el('line', { x1: left, x2: left + w, y1: y(t), y2: y(t), stroke: 'var(--grid)' }));
      svg.appendChild(el('text', { x: left - 10, y: y(t) + 4, 'text-anchor': 'end', 'font-size': 15, fill: 'var(--muted)', 'font-family': DISPLAY }, num(t)));
    });
    xs.forEach(function (rotulo, i) {
      svg.appendChild(el('text', { x: x(i), y: base + 22, 'text-anchor': 'middle', 'font-size': 15, fill: 'var(--muted)', 'font-family': DISPLAY }, rotulo));
    });
    cfg.series.forEach(function (s) {
      var d = s.valores.map(function (v, i) { return (i ? 'L' : 'M') + x(i) + ',' + y(v); }).join(' ');
      svg.appendChild(el('path', { d: d, fill: 'none', stroke: s.cor, 'stroke-width': 3.5 }));
      s.valores.forEach(function (v, i) {
        var c = el('circle', { cx: x(i), cy: y(v), r: 4.5, fill: s.cor });
        c.appendChild(el('title', {}, s.nome + ', ' + xs[i] + ': ' + num(v) + ' ' + (cfg.unidade || '')));
        svg.appendChild(c);
      });
      var ultimo = s.valores.length - 1;
      svg.appendChild(el('text', { x: x(0) + 8, y: y(s.valores[0]) - 12, 'font-size': 16, fill: 'var(--ink)', 'font-family': DISPLAY }, num(s.valores[0]) + ' mi'));
      svg.appendChild(el('text', { x: x(ultimo) + 12, y: y(s.valores[ultimo]) + 5, 'font-size': 17, 'font-weight': 600, fill: s.cor, 'font-family': DISPLAY }, s.nome + ': ' + num(s.valores[ultimo]) + ' mi'));
    });
  }

  /* Gráfico de barras agrupadas.
     { alvo:'chart-soy', titulo, subtitulo, maxY:80, periodos:['2017','2024'],
       grupos:[{nome:'Brasil', cor:'var(--gold)', valores:[53,71]}] } */
  function barras(cfg) {
    var svg = document.getElementById(cfg.alvo);
    if (!svg || svg.childNodes.length) return;
    var left = 60, topo = 100, base = 320, bw = 70, gap = 10;
    var y = function (v) { return base - (v / cfg.maxY) * (base - topo); };

    titulos(svg, cfg.titulo, cfg.subtitulo);
    svg.appendChild(el('line', { x1: left, x2: 720, y1: base, y2: base, stroke: 'var(--muted)' }));

    cfg.grupos.forEach(function (g, gi) {
      var gx = left + 40 + gi * 220;
      g.valores.forEach(function (v, pi) {
        var bx = gx + pi * (bw + gap);
        var r = el('rect', { x: bx, y: y(v), width: bw, height: base - y(v), fill: g.cor, 'fill-opacity': pi ? 1 : .4, rx: 3 });
        r.appendChild(el('title', {}, g.nome + ', ' + cfg.periodos[pi] + ': ' + v + '%'));
        svg.appendChild(r);
        svg.appendChild(el('text', { x: bx + bw / 2, y: y(v) - 8, 'text-anchor': 'middle', 'font-size': 17, fill: 'var(--ink)', 'font-family': DISPLAY }, v + '%'));
        svg.appendChild(el('text', { x: bx + bw / 2, y: base + 20, 'text-anchor': 'middle', 'font-size': 15, fill: 'var(--muted)', 'font-family': DISPLAY }, cfg.periodos[pi]));
      });
      svg.appendChild(el('text', { x: gx + bw + gap / 2, y: base + 46, 'text-anchor': 'middle', 'font-size': 18, 'font-weight': 600, fill: 'var(--ink)', 'font-family': DISPLAY }, g.nome));
    });
  }

  /* Alternador de versão. O modo escolhido fica no endereço,
     então o link #completa abre direto na análise longa. */
  function modos() {
    var botoes = document.querySelectorAll('.modes button');
    if (!botoes.length) return;
    function aplicar(m) {
      document.querySelectorAll('[data-modo]').forEach(function (bloco) {
        bloco.hidden = bloco.dataset.modo !== m;
      });
      botoes.forEach(function (b) { b.setAttribute('aria-pressed', b.dataset.modo === m ? 'true' : 'false'); });
    }
    botoes.forEach(function (b) {
      b.addEventListener('click', function () {
        history.replaceState(null, '', '#' + b.dataset.modo);
        aplicar(b.dataset.modo);
      });
    });
    document.querySelectorAll('[data-abrir]').forEach(function (a) {
      a.addEventListener('click', function () { aplicar(a.dataset.abrir); });
    });
    aplicar(location.hash === '#completa' ? 'completa' : 'rapida');
  }

  window.Heartland = { linhas: linhas, barras: barras };
  document.addEventListener('DOMContentLoaded', modos);
})();
