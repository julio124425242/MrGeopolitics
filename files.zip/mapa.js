/* Mapa da home: os dois países lado a lado e depois sobrepostos.
   Os contornos vêm de assets/mapa-dados.js */
(function () {
  var stage = document.getElementById('map-svg');
  if (!stage || !window.HEARTLAND_MAPA) return;

  var us = document.getElementById('shape-us');
  var cn = document.getElementById('shape-cn');
  us.querySelector('path').setAttribute('d', window.HEARTLAND_MAPA.us);
  cn.querySelector('path').setAttribute('d', window.HEARTLAND_MAPA.cn);

  var btn = document.getElementById('toggle-map');
  var narrow = window.matchMedia('(max-width:640px)');
  var overlaid = false;

  function setMap(o) {
    overlaid = o;
    us.style.transform = o ? 'translateX(300px)' : 'translateX(0px)';
    cn.style.transform = o ? 'translateX(-300px)' : 'translateX(0px)';
    btn.textContent = o ? 'Ver lado a lado' : 'Sobrepor os dois';
    btn.setAttribute('aria-pressed', o ? 'true' : 'false');
    if (narrow.matches) stage.setAttribute('viewBox', o ? '330 20 500 390' : '0 0 1200 424');
    else stage.setAttribute('viewBox', '0 0 1200 424');
  }

  setMap(false);
  btn.addEventListener('click', function () { setMap(!overlaid); });
  narrow.addEventListener('change', function () { setMap(overlaid); });

  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (reduce) setMap(true);
  else setTimeout(function () { if (!overlaid) setMap(true); }, 1400);
})();
