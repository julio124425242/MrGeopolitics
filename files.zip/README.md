# Heartland

Site de geopolítica: um vídeo de um minuto e um artigo com dados e fontes para cada tema.

Site estático, sem banco de dados e sem build. É só HTML, CSS e JavaScript, então
qualquer hospedagem de arquivos serve.

## O que tem em cada arquivo

| Arquivo | Para que serve |
| --- | --- |
| `index.html` | Home, com o mapa de abertura e a lista de artigos |
| `sobre.html` | Página Sobre |
| `artigos/eua-china.html` | Primeiro artigo |
| `artigos/_modelo.html` | Modelo para copiar a cada artigo novo |
| `assets/estilo.css` | Todo o visual do site, em um lugar só |
| `assets/artigo.js` | Alternador rápida/completa e os gráficos |
| `assets/mapa.js` | Animação do mapa da home |
| `assets/mapa-dados.js` | Contornos de EUA e China, Natural Earth, projeção de área igual |
| `assets/og.png` | Imagem que aparece ao compartilhar o link no WhatsApp e nas redes |
| `assets/favicon.svg` | Ícone da aba do navegador |
| `sitemap.xml`, `robots.txt` | Ajudam o Google a indexar o site |

## Colocar no ar pelo GitHub Pages

1. Crie uma conta em github.com.
2. Crie um repositório novo chamado `heartland`, público, sem adicionar README.
3. Envie os arquivos. Pelo navegador: abra o repositório, clique em **uploading an existing file**
   e arraste a pasta inteira. Pelo terminal:

   ```bash
   cd heartland
   git init
   git add .
   git commit -m "Primeiro artigo"
   git branch -M main
   git remote add origin https://github.com/SEU-USUARIO/heartland.git
   git push -u origin main
   ```

4. No repositório, vá em **Settings**, depois **Pages**. Em Source escolha
   **Deploy from a branch**, branch `main`, pasta `/ (root)`, e salve.
5. Em um ou dois minutos o site fica no ar em
   `https://SEU-USUARIO.github.io/heartland/`.

### Trocar o endereço nos arquivos

Procure por `SEU-USUARIO` em `index.html`, `sobre.html`, `artigos/eua-china.html`,
`sitemap.xml` e `robots.txt`, e troque pelo seu usuário do GitHub ou pelo seu domínio
próprio. Isso é o que faz o link ficar bonito quando alguém compartilha no WhatsApp.

### Domínio próprio, opcional

Registre em registro.br para `.com.br` ou em Cloudflare e Namecheap para `.com`.
Depois, em Settings, Pages, campo Custom domain, informe o domínio e siga as instruções
de DNS que o GitHub mostra.

## Publicar um artigo novo

1. Copie `artigos/_modelo.html` para `artigos/nome-do-artigo.html`, sem acentos no nome.
2. Escreva o texto e troque tudo que está entre colchetes, inclusive título,
   descrição e data no topo do arquivo.
3. Abra `index.html` e cole um bloco novo no começo da lista de artigos:

   ```html
   <a class="entry" href="artigos/nome-do-artigo.html">
     <span class="entry-date">5 out 2026</span>
     <span>
       <h3>Título do artigo</h3>
       <p>Uma linha dizendo do que se trata.</p>
     </span>
   </a>
   ```

4. Acrescente a URL no `sitemap.xml`.
5. Faça commit e push. O site atualiza sozinho.

## Encaixar o vídeo

Na página do artigo, troque o bloco `<div class="video-placeholder">` por:

```html
<div class="video">COLE AQUI O CÓDIGO DE INCORPORAR</div>
```

No Instagram, o código sai no menu de três pontos do post, opção Incorporar.
No YouTube, no botão Compartilhar, opção Incorporar. Não suba o arquivo MP4 para o
repositório: vídeo pesado deixa o site lento e estoura o limite de armazenamento.

## Gráficos

Cada artigo cria seus gráficos no final do arquivo, com os dados na própria página.
Dois formatos estão prontos, `Heartland.linhas` e `Heartland.barras`, e os exemplos
comentados estão no modelo.

## Testar antes de publicar

Abrir o `index.html` com dois cliques já funciona. Se quiser um servidor local:

```bash
python3 -m http.server 8000
```

Depois acesse `http://localhost:8000`.

## Créditos dos dados

Contornos dos países: Natural Earth, domínio público, via o pacote `world-atlas`,
reprojetados em azimutal equivalente para que as áreas sejam comparáveis.
As fontes de cada número estão listadas no fim de cada artigo.
